# Details

Date : 2022-04-24 11:58:19

Directory c:\Users\Administrator\Desktop\tntjs

Total : 15 files,  3256 codes, 67 comments, 42 blanks, all 3365 lines

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [README.en.md](/README.en.md) | Markdown | 37 | 0 | 3 | 40 |
| [README.jp.md](/README.jp.md) | Markdown | 37 | 0 | 6 | 43 |
| [README.md](/README.md) | Markdown | 53 | 0 | 5 | 58 |
| [TNTGlobal.ts](/TNTGlobal.ts) | TypeScript | 13 | 1 | 0 | 14 |
| [TNTSymbolTable.ts](/TNTSymbolTable.ts) | TypeScript | 50 | 0 | 3 | 53 |
| [index.html](/index.html) | HTML | 19 | 0 | 0 | 19 |
| [package-lock.json](/package-lock.json) | JSON | 2,086 | 0 | 1 | 2,087 |
| [package.json](/package.json) | JSON | 22 | 0 | 1 | 23 |
| [setup.ts](/setup.ts) | TypeScript | 12 | 0 | 0 | 12 |
| [test/own_value.js](/test/own_value.js) | JavaScript | 8 | 0 | 0 | 8 |
| [test/var.js](/test/var.js) | JavaScript | 177 | 18 | 7 | 202 |
| [tnt.d.ts](/tnt.d.ts) | TypeScript | 21 | 0 | 1 | 22 |
| [tnt.js](/tnt.js) | JavaScript | 393 | 1 | 0 | 394 |
| [tnt.ts](/tnt.ts) | TypeScript | 311 | 47 | 15 | 373 |
| [tsconfig.json](/tsconfig.json) | JSON with Comments | 17 | 0 | 0 | 17 |

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)