# Summary

Date : 2022-04-24 11:58:19

Directory c:\Users\Administrator\Desktop\tntjs

Total : 15 files,  3256 codes, 67 comments, 42 blanks, all 3365 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| JSON | 2 | 2,108 | 0 | 2 | 2,110 |
| JavaScript | 3 | 578 | 19 | 7 | 604 |
| TypeScript | 5 | 407 | 48 | 19 | 474 |
| Markdown | 3 | 127 | 0 | 14 | 141 |
| HTML | 1 | 19 | 0 | 0 | 19 |
| JSON with Comments | 1 | 17 | 0 | 0 | 17 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 15 | 3,256 | 67 | 42 | 3,365 |
| test | 2 | 185 | 18 | 7 | 210 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)